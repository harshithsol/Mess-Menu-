# Mess Menu

Offline-first Android app that tells you what meal is being served right now
(or what's next), based on a 4-week rotating menu you import from a plain
text file.

## What's implemented

- Kotlin + Jetpack Compose + Material 3, MVVM, StateFlow/ViewModel, Navigation Compose
- Menu import via Storage Access Framework from a plain `.txt` file (no third-party parsing library needed)
- Parsed menu cached in DataStore as JSON — works offline even if the original file is deleted
- 4-week rotation computed automatically from a user-chosen Week 1 start date, with a manual override (Week 1-4 selector)
- Live "now serving / next meal" logic with a per-second countdown, no refresh button
- Editable meal timings (Material time pickers) with Restore Defaults
- Onboarding flow: Welcome → Import → Week 1 start date → Timings → Finish
- Settings screen: import/replace/delete menu, preview, week controls, timings, notification preference, about
- Dark, orange-accented Material 3 theme per the design brief
- Sample file at `sample_menu.txt` in this folder, matching the exact expected format

## Text file format

Plain `.txt` file. First non-comment line must be exactly this header
(case-insensitive):

```
Week|Day|Breakfast|Lunch|Snacks|Dinner
```

Then one line per day, fields separated by `|`, multiple dishes within a
field separated by commas. Lines starting with `#` and blank lines are
ignored, so you can add comments. All 4 weeks x 7 days (28 data lines) are
required. Example:

```
Week 1|Monday|Idli, Sambar, Chutney|Rice, Dal, Mixed Veg|Samosa, Tea|Chapati, Paneer Curry
Week 1|Tuesday|Dosa, Chutney|Fried Rice, Manchurian|Sandwich, Coffee|Rice, Rasam, Curd
```

See `sample_menu.txt` for a complete 28-line example you can edit directly.
Because it's plain text, you can write it in any text editor, Google Keep,
Notes app, etc. — no spreadsheet software required.

## Trimmed / assumed, documented rather than guessed

- **Notifications**: Settings captures the user's preference (off / at start /
  15 min / 30 min before), but the `WorkManager` scheduling worker itself
  is not wired up yet — the model is in place, the worker file is not.
- **Room** was skipped in favor of DataStore+JSON for the cached menu.
- **Hilt** was skipped in favor of plain constructor injection (repository is
  constructed once in `MainActivity` and passed down).
- **Bonus features** (widget, dish search, favorites, share, PDF export, multiple
  hostels, swipe-between-days, pull-to-refresh) are not implemented.
- **Week rotation assumption**: the 28-day cycle is computed from the exact date
  the user selects as "Week 1 start," not forced to Monday. If your mess resets
  strictly on Mondays, pick a Monday during onboarding.

## Project structure

```
app/src/main/java/com/messmenu/app/
  data/
    model/        MenuModels.kt          - data classes (menu, timings, settings)
    textparse/    TextMenuParser.kt      - plain-text menu parsing + validation
    datastore/    PreferencesManager.kt  - DataStore reads/writes
    repository/   MenuRepository.kt      - single source of truth for UI
  domain/         MealLogic.kt           - pure "what's serving now / next" logic
  utils/          WeekCalculator.kt      - 4-week cycle math
  navigation/     MessMenuNavGraph.kt
  ui/
    onboarding/   OnboardingScreen.kt
    home/         HomeScreen.kt, HomeViewModel.kt
    settings/     SettingsScreen.kt, SettingsViewModel.kt
    theme/        Color.kt, Theme.kt
  MainActivity.kt
```

## Building (Android Studio, USB to phone)

1. Install Android Studio (developer.android.com/studio).
2. File → Open → select this unzipped `MessMenu` folder.
3. Wait for Gradle sync to finish (downloads Gradle + dependencies automatically — no manual Gradle install needed).
4. On your phone: Settings → About Phone → tap "Build number" 7x → Developer Options unlocked → enable USB Debugging.
5. Plug phone into PC via USB, tap "Allow" on the phone's popup.
6. In Android Studio, pick your phone from the device dropdown → click Run ▶.
7. App installs and launches on your phone.

Alternative: Build → Build APK(s), then copy the resulting `.apk` from
`app/build/outputs/apk/debug/` to your phone manually and install it.

## Known gaps to close before shipping

- Wire up the notification `WorkManager` worker using the stored lead-time preference.
- Add a proper app icon/adaptive icon instead of the placeholder system drawable.
- Add unit tests for `WeekCalculator` and `MealLogic` (both are pure functions, easy to test).
- Handle the case where the imported file is missing lines for some days (currently falls back to "No dishes listed").

---

## Extension: widget, shortcuts, and the richer home screen

This round added, on top of the original app, **without rebuilding it**:

- **Home screen widget** (`widget/` package, Jetpack Glance): shows Week N / day,
  "Now Serving" or "Next Meal", the meal name, and its time window. Tapping it
  opens the app. It reuses `domain/CurrentMealResolver.kt` — the same meal-resolution
  logic the home screen uses — so the widget and the in-app screen can never disagree.
- **App shortcut**: long-press the app icon → **"Today's Meals"** opens straight to
  the home screen, which already defaults to today.
- **Redesigned home screen** (already present in this codebase pre-extension, verified
  and left intact): full day schedule with the current meal elevated/highlighted,
  swipe-left/right or arrow-button day navigation, a calendar date picker for jumping
  to any date (auto-resolves the correct week/day), a Week 1-4 preview row for
  browsing the rotation without touching your real settings, a "Quick Meals" bottom
  sheet that scrolls the list to the tapped meal, and fade/cross-fade transitions
  between days.

### Trimmed / assumed here too

- **Widget refresh cadence**: exact-to-the-minute updates when a meal starts/ends
  or at midnight would need Android's exact-alarm scheduling
  (`SCHEDULE_EXACT_ALARM`), which is a heavy permission/battery ask for a "what's
  for lunch" widget. Instead it refreshes immediately whenever you change the menu
  or settings in-app, plus a 15-minute background WorkManager tick (WorkManager's
  minimum interval) as a fallback for when the app isn't open. So the widget can
  lag a real boundary by up to ~15 minutes if you haven't opened the app recently.
- **Dynamic shortcuts** ("Next Meal", "Tomorrow's Menu") were not added — only the
  static "Today's Meals" shortcut. Dynamic shortcuts need to be re-pushed via
  `ShortcutManager` every time the current/next meal changes, which is a fair bit
  of extra plumbing for a feature the prompt itself flagged as conditional
  ("if Android version allows").
- **Architecture note**: `MenuRepository` now calls into the `widget` package
  directly to trigger refreshes after a save. That's a small, intentional layering
  shortcut (data layer briefly reaching into the UI/widget layer) rather than
  building a full event-bus for an app this size — flagged here instead of hidden.
- The widget is new/less-common surface API (Jetpack Glance) that I could not
  compile locally — same caveat as the rest of the app. If Android Studio flags
  an error in the `widget/` package specifically, send it over.

---

## Fix + notifications wired up (this round)

- **Build fix**: `HomeScreen.kt` had a wrong import path — `pointerInput` was
  imported from `androidx.compose.ui.input` instead of the correct
  `androidx.compose.ui.input.pointer`. That single bad import broke type
  inference for everything below it in the file (the cascade of "cannot infer
  type" / "overload ambiguity" errors you saw all trace back to this one line).
- **Notifications now actually fire.** Previously the Settings screen only
  captured your lead-time preference — nothing scheduled a real alert. Now:
  - `notifications/NotificationScheduler.kt` computes the next meal trigger
    (start time minus your chosen lead) and enqueues a single precise
    WorkManager job for that exact moment.
  - `notifications/MealNotificationWorker.kt` fires the alert (with today's
    dishes for that meal, when available) and immediately re-schedules the
    *next* trigger — a self-chaining sequence rather than a fixed periodic
    poll, so alerts land close to the real minute instead of a 15-minute window.
  - The chain is (re)built automatically whenever you change meal timings or
    the notification preference in Settings, and once on every app launch.
  - Android 13+ requires the `POST_NOTIFICATIONS` runtime permission before
    any notification can post — the app now requests it once on first launch.
    If you deny it, notifications silently no-op (the in-app countdown still
    works); there's no in-app "ask again" flow yet — you'd need to grant it
    via system Settings → Apps → Mess Menu → Notifications.
