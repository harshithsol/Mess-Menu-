# No third-party reflection-heavy libraries remain (menu import is a plain
# text file parser), so no extra keep rules are currently required.
