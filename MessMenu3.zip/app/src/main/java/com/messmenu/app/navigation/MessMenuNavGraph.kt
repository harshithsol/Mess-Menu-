package com.messmenu.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.messmenu.app.data.repository.MenuRepository
import com.messmenu.app.ui.home.HomeScreen
import com.messmenu.app.ui.home.HomeViewModel
import com.messmenu.app.ui.onboarding.OnboardingScreen
import com.messmenu.app.ui.settings.SettingsScreen
import com.messmenu.app.ui.settings.SettingsViewModel

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val SETTINGS = "settings"
}

@Composable
fun MessMenuNavGraph(repository: MenuRepository) {
    val navController: NavHostController = rememberNavController()

    var onboardingDone by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(Unit) {
        onboardingDone = repository.currentSettings().onboardingComplete
    }

    if (onboardingDone == null) return // brief splash-less wait for the first read

    NavHost(
        navController = navController,
        startDestination = if (onboardingDone == true) Routes.HOME else Routes.ONBOARDING
    ) {
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                repository = repository,
                onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            val vm = remember { HomeViewModel(repository) }
            HomeScreen(
                viewModel = vm,
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.SETTINGS) {
            val vm = remember { SettingsViewModel(repository) }
            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
