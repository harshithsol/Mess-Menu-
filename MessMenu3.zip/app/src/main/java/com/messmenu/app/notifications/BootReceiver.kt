package com.messmenu.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * WorkManager's queue is cleared on device reboot, and [NotificationScheduler]
 * is otherwise only re-armed from [com.messmenu.app.MainActivity] or when menu
 * data changes. Without this receiver, meal alerts silently stop firing after
 * every reboot until the user happens to open the app.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val request = OneTimeWorkRequestBuilder<RescheduleWorker>().build()
        WorkManager.getInstance(context).enqueue(request)
    }
}
