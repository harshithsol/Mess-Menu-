package com.messmenu.app.domain

import com.messmenu.app.data.model.*
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/**
 * Pure logic: given the timings config, a day's menu (and tomorrow's, in case
 * we roll over past dinner), and the current time, determine what to show.
 */
object MealLogic {

    private val ORDER = listOf(MealType.BREAKFAST, MealType.LUNCH, MealType.SNACKS, MealType.DINNER)

    fun computeState(
        now: LocalDateTime,
        timings: MealTimingsConfig,
        todayMenu: DayMenu,
        tomorrowMenu: DayMenu
    ): CurrentMealState {
        val nowMinutes = now.hour * 60 + now.minute

        // 1) Currently inside a meal window?
        for (meal in ORDER) {
            val t = timings.forMeal(meal)
            if (nowMinutes in t.startTotalMinutes() until t.endTotalMinutes()) {
                return CurrentMealState(
                    status = MealStatus.NOW_SERVING,
                    meal = meal,
                    dishes = todayMenu.forMeal(meal),
                    timing = t
                )
            }
        }

        // 2) Otherwise find the next upcoming meal today.
        for (meal in ORDER) {
            val t = timings.forMeal(meal)
            if (nowMinutes < t.startTotalMinutes()) {
                return CurrentMealState(
                    status = MealStatus.UPCOMING,
                    meal = meal,
                    dishes = todayMenu.forMeal(meal),
                    timing = t
                )
            }
        }

        // 3) Past dinner: next meal is tomorrow's breakfast.
        val breakfastTiming = timings.breakfast
        return CurrentMealState(
            status = MealStatus.UPCOMING,
            meal = MealType.BREAKFAST,
            dishes = tomorrowMenu.breakfast,
            timing = breakfastTiming,
            isNextDay = true
        )
    }

    /**
     * Full schedule for one day, in meal order. Current/next/past flags are
     * only meaningful when [isToday] is true (i.e. the day being viewed is the
     * real, actual today) — when browsing other dates we just list the meals
     * with no highlighting.
     */
    fun fullDaySchedule(
        now: LocalDateTime,
        timings: MealTimingsConfig,
        dayMenu: DayMenu,
        isToday: Boolean
    ): List<MealScheduleEntry> {
        val nowMinutes = now.hour * 60 + now.minute
        var nextAssigned = false

        // First pass: figure out which single meal (if any) is "current".
        val currentMeal = if (isToday) {
            ORDER.firstOrNull { meal ->
                val t = timings.forMeal(meal)
                nowMinutes in t.startTotalMinutes() until t.endTotalMinutes()
            }
        } else null

        return ORDER.map { meal ->
            val t = timings.forMeal(meal)
            val isCurrent = isToday && meal == currentMeal
            val isPast = isToday && !isCurrent && nowMinutes >= t.endTotalMinutes()
            val isNext = isToday && currentMeal == null && !nextAssigned && nowMinutes < t.startTotalMinutes()
            if (isNext) nextAssigned = true
            MealScheduleEntry(
                meal = meal,
                timing = t,
                dishes = dayMenu.forMeal(meal),
                isCurrent = isCurrent,
                isNext = isNext,
                isPast = isPast
            )
        }
    }

    /** Seconds remaining until the given timing's relevant boundary. */
    fun secondsUntil(now: LocalDateTime, state: CurrentMealState): Long {
        val targetTime = if (state.status == MealStatus.NOW_SERVING) {
            LocalTime.of(state.timing.endHour, state.timing.endMinute)
        } else {
            LocalTime.of(state.timing.startHour, state.timing.startMinute)
        }
        var target = now.toLocalDate().atTime(targetTime)
        if (state.isNextDay || target.isBefore(now)) {
            target = target.plusDays(1)
        }
        return java.time.Duration.between(now, target).seconds.coerceAtLeast(0)
    }
}
