package com.messmenu.app.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.messmenu.app.data.model.*
import com.messmenu.app.data.repository.MenuRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val menu: MessMenuData? = null,
    val importError: String? = null,
    val importSuccessMessage: String? = null
)

class SettingsViewModel(private val repository: MenuRepository) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> =
        combine(repository.settingsFlow, repository.menuFlow) { settings, menu ->
            SettingsUiState(settings = settings, menu = menu)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsUiState())

    fun importMenu(uri: Uri, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = repository.importMenu(uri)
            result.onSuccess { onDone(true, "Menu imported successfully.") }
                .onFailure { onDone(false, it.message ?: "Could not read the file.") }
        }
    }

    fun deleteMenu() {
        viewModelScope.launch { repository.deleteMenu() }
    }

    fun setWeek1Start(epochDay: Long) {
        viewModelScope.launch { repository.setWeek1Start(epochDay) }
    }

    fun setAutomaticWeekCalculation(enabled: Boolean) {
        viewModelScope.launch { repository.setAutomaticWeekCalculation(enabled) }
    }

    fun setManualWeek(week: Int) {
        viewModelScope.launch { repository.setManualWeek(week) }
    }

    fun setTimings(timings: MealTimingsConfig) {
        viewModelScope.launch { repository.setTimings(timings) }
    }

    fun restoreDefaultTimings() {
        viewModelScope.launch { repository.setTimings(MealTimingsConfig.default()) }
    }

    fun setNotificationLeadTime(leadTime: NotificationLeadTime) {
        viewModelScope.launch { repository.setNotificationSettings(NotificationSettings(leadTime)) }
    }
}
