package com.messmenu.app.widget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Refreshes the home screen widget. Triggered two ways:
 *  1. Immediately, whenever the app changes the menu/settings (see [WidgetScheduler.refreshNow]).
 *  2. Periodically (every 15 minutes — WorkManager's minimum periodic interval)
 *     so the widget still updates when the app isn't open and a meal boundary
 *     or midnight passes.
 *
 * Note: 15 minutes means the widget can lag up to ~15 min behind an exact
 * meal start/end time when the app is closed. Hitting the exact minute would
 * need scheduled exact alarms (SCHEDULE_EXACT_ALARM), which is a much bigger
 * permission/battery tradeoff for a "what's for lunch" app — documented here
 * as an intentional simplification rather than left unstated.
 */
class WidgetRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            MessMenuWidget().updateAll(context = applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
