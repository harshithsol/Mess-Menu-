package com.messmenu.app.domain

import com.messmenu.app.data.model.*
import java.time.LocalDateTime

enum class MealHighlight { NONE, CURRENT, NEXT }

data class MealScheduleItem(
    val meal: MealType,
    val dishes: List<String>,
    val timing: MealTiming,
    val highlight: MealHighlight
)

/**
 * Builds the ordered list of all four meals for a single day, marking which
 * one (if any) is currently being served or is the next upcoming meal.
 * Highlighting is only meaningful when [dayMenu] is for "today" and [now]
 * reflects the real current time — pass isToday = false when browsing other
 * days to keep everything unhighlighted.
 */
object DayScheduleLogic {

    private val ORDER = listOf(MealType.BREAKFAST, MealType.LUNCH, MealType.SNACKS, MealType.DINNER)

    fun buildSchedule(
        now: LocalDateTime,
        timings: MealTimingsConfig,
        dayMenu: DayMenu,
        isToday: Boolean
    ): List<MealScheduleItem> {
        if (!isToday) {
            return ORDER.map { meal ->
                MealScheduleItem(meal, dayMenu.forMeal(meal), timings.forMeal(meal), MealHighlight.NONE)
            }
        }

        val nowMinutes = now.hour * 60 + now.minute

        // Find currently-serving meal, if any.
        val currentMeal = ORDER.firstOrNull { meal ->
            val t = timings.forMeal(meal)
            nowMinutes in t.startTotalMinutes() until t.endTotalMinutes()
        }

        // Find next upcoming meal today (first one starting after now), only
        // relevant when nothing is currently serving.
        val nextMeal = if (currentMeal == null) {
            ORDER.firstOrNull { meal -> nowMinutes < timings.forMeal(meal).startTotalMinutes() }
        } else null

        return ORDER.map { meal ->
            val highlight = when (meal) {
                currentMeal -> MealHighlight.CURRENT
                nextMeal -> MealHighlight.NEXT
                else -> MealHighlight.NONE
            }
            MealScheduleItem(meal, dayMenu.forMeal(meal), timings.forMeal(meal), highlight)
        }
    }
}
