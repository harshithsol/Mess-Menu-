package com.messmenu.app.data.textparse

import com.messmenu.app.data.model.DayMenu
import com.messmenu.app.data.model.MessMenuData
import com.messmenu.app.data.model.WeekDay
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

class MenuFormatException(message: String) : Exception(message)

/**
 * Parses a plain-text mess menu file.
 *
 * Expected format: one header line, then one line per day, fields separated
 * by the pipe character "|". Multiple dishes within a field are separated by
 * commas. Blank lines and lines starting with "#" are ignored.
 *
 * Header (required, case-insensitive, exact field order):
 *   Week|Day|Breakfast|Lunch|Snacks|Dinner
 *
 * Data row example:
 *   Week 1|Monday|Idli, Sambar, Chutney|Rice, Dal, Mixed Veg|Samosa, Tea|Chapati, Paneer Curry
 *
 * All 4 weeks (Week 1 - Week 4), 7 days each, are required.
 */
object TextMenuParser {

    private const val DELIMITER = "|"
    private val EXPECTED_HEADERS = listOf("week", "day", "breakfast", "lunch", "snacks", "dinner")

    fun parse(input: InputStream): MessMenuData {
        val reader = BufferedReader(InputStreamReader(input))
        val lines = reader.useLines { seq ->
            seq.map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .toList()
        }

        if (lines.isEmpty()) {
            throw MenuFormatException("The file is empty.")
        }

        val header = lines.first().split(DELIMITER).map { it.trim().lowercase() }
        if (header != EXPECTED_HEADERS) {
            throw MenuFormatException(
                "Invalid header line. Expected: Week|Day|Breakfast|Lunch|Snacks|Dinner. " +
                    "Found: ${lines.first()}"
            )
        }

        val weeks = mutableMapOf<Int, MutableList<DayMenu>>()

        lines.drop(1).forEachIndexed { idx, line ->
            val lineNumber = idx + 2 // account for header + 1-based
            val fields = line.split(DELIMITER).map { it.trim() }
            if (fields.size != 6) {
                throw MenuFormatException(
                    "Line $lineNumber: expected 6 fields separated by \"|\", found ${fields.size}. Line: \"$line\""
                )
            }

            val weekNum = parseWeekNumber(fields[0], lineNumber)
            val day = parseDay(fields[1], lineNumber)
            val breakfast = splitDishes(fields[2])
            val lunch = splitDishes(fields[3])
            val snacks = splitDishes(fields[4])
            val dinner = splitDishes(fields[5])

            val dayMenu = DayMenu(day, breakfast, lunch, snacks, dinner)
            weeks.getOrPut(weekNum) { mutableListOf() }.add(dayMenu)
        }

        if (weeks.isEmpty()) {
            throw MenuFormatException("No data rows found under the header.")
        }
        for (w in 1..4) {
            if (weeks[w].isNullOrEmpty()) {
                throw MenuFormatException("Week $w has no rows. All 4 weeks (Week 1 - Week 4) are required.")
            }
        }

        return MessMenuData(weeks = weeks)
    }

    private fun parseWeekNumber(text: String, lineNumber: Int): Int {
        val digits = Regex("\\d+").find(text)?.value
            ?: throw MenuFormatException("Line $lineNumber: could not read week number from \"$text\". Expected e.g. \"Week 1\".")
        val n = digits.toInt()
        if (n !in 1..4) {
            throw MenuFormatException("Line $lineNumber: week number $n is out of range. Must be 1-4.")
        }
        return n
    }

    private fun parseDay(text: String, lineNumber: Int): WeekDay {
        return when (text.trim().lowercase()) {
            "monday", "mon" -> WeekDay.MONDAY
            "tuesday", "tue" -> WeekDay.TUESDAY
            "wednesday", "wed" -> WeekDay.WEDNESDAY
            "thursday", "thu" -> WeekDay.THURSDAY
            "friday", "fri" -> WeekDay.FRIDAY
            "saturday", "sat" -> WeekDay.SATURDAY
            "sunday", "sun" -> WeekDay.SUNDAY
            else -> throw MenuFormatException("Line $lineNumber: unrecognized day \"$text\".")
        }
    }

    private fun splitDishes(text: String): List<String> =
        text.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
}
