package com.messmenu.app.widget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object WidgetScheduler {

    private const val PERIODIC_WORK_NAME = "mess_menu_widget_periodic_refresh"

    /** Call once (e.g. app start) to keep the widget updating in the background. */
    fun schedulePeriodicRefresh(context: Context) {
        val request = PeriodicWorkRequestBuilder<WidgetRefreshWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /**
     * Call right after the menu, timings, or week settings change so any
     * placed widget reflects the edit immediately instead of waiting for the
     * next periodic tick. Safe to call even if no widget is currently placed.
     */
    suspend fun refreshNow(context: Context) {
        try {
            MessMenuWidget().updateAll(context)
        } catch (_: Exception) {
            // No widget instances placed yet, or a transient Glance error —
            // never let a widget refresh failure break the actual app action.
        }
    }
}
