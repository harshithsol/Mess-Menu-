package com.messmenu.app.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundBlack = Color(0xFF0A0A0A)
val SurfaceDarkGray = Color(0xFF1C1C1E)
val SurfaceElevated = Color(0xFF262628)
val OrangeAccent = Color(0xFFFF7A1A)
val OrangeAccentDim = Color(0xFFCC5F0F)
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFA0A0A3)
val ErrorRed = Color(0xFFFF5449)
