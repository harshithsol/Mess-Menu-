package com.messmenu.app.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.messmenu.app.data.model.MealType
import com.messmenu.app.data.model.WeekDay
import com.messmenu.app.domain.MealHighlight
import com.messmenu.app.domain.MealScheduleItem
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel, onOpenSettings: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    var showDatePicker by remember { mutableStateOf(false) }
    var showQuickMeals by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mess Menu") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            if (state is HomeUiState.Loaded && (state as HomeUiState.Loaded).schedule.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { showQuickMeals = true },
                    icon = { Icon(Icons.Filled.RestaurantMenu, contentDescription = null) },
                    text = { Text("Quick Meals") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val s = state) {
                is HomeUiState.NoMenuImported -> NoMenuState(onOpenSettings)
                is HomeUiState.Loaded -> LoadedContent(
                    state = s,
                    listState = listState,
                    onPrevDay = {
                        if (s.browseMode == BrowseMode.WEEK_PREVIEW) viewModel.previewPreviousDay()
                        else viewModel.goToPreviousDay()
                    },
                    onNextDay = {
                        if (s.browseMode == BrowseMode.WEEK_PREVIEW) viewModel.previewNextDay()
                        else viewModel.goToNextDay()
                    },
                    onOpenDatePicker = { showDatePicker = true },
                    onSelectPreviewWeek = { viewModel.previewWeek(it) },
                    onSelectPreviewDay = { viewModel.previewDay(it) },
                    onBackToToday = { viewModel.goToToday() }
                )
            }
        }
    }

    if (showDatePicker) {
        val current = (state as? HomeUiState.Loaded)?.selectedDate ?: LocalDate.now()
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = current.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        val date = java.time.Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate()
                        viewModel.goToDate(date)
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = pickerState, showModeToggle = false)
        }
    }

    if (showQuickMeals) {
        val s = state as? HomeUiState.Loaded
        if (s != null) {
            ModalBottomSheet(onDismissRequest = { showQuickMeals = false }) {
                QuickMealsSheetContent(
                    schedule = s.schedule,
                    onMealTapped = { index ->
                        scope.launch { listState.animateScrollToItem(index) }
                        showQuickMeals = false
                    }
                )
            }
        }
    }
}

@Composable
private fun NoMenuState(onOpenSettings: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No menu imported.", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("Import Menu")
        }
    }
}

@Composable
private fun LoadedContent(
    state: HomeUiState.Loaded,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onPrevDay: () -> Unit,
    onNextDay: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onSelectPreviewWeek: (Int) -> Unit,
    onSelectPreviewDay: (WeekDay) -> Unit,
    onBackToToday: () -> Unit
) {
    var dragAccum by remember { mutableStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { dragAccum = 0f },
                    onHorizontalDrag = { _, dragAmount -> dragAccum += dragAmount },
                    onDragEnd = {
                        if (abs(dragAccum) > 120f) {
                            if (dragAccum < 0) onNextDay() else onPrevDay()
                        }
                        dragAccum = 0f
                    }
                )
            }
    ) {
        DayHeader(
            state = state,
            onPrevDay = onPrevDay,
            onNextDay = onNextDay,
            onOpenDatePicker = onOpenDatePicker,
            onBackToToday = onBackToToday
        )

        WeekPreviewRow(
            selectedWeek = state.weekNumber,
            isPreviewMode = state.browseMode == BrowseMode.WEEK_PREVIEW,
            onSelectWeek = onSelectPreviewWeek
        )

        AnimatedContent(
            targetState = Triple(state.selectedDate, state.weekNumber, state.dayName) to state.browseMode,
            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
            label = "day_content"
        ) { _ ->
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp, 4.dp, 20.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (state.isToday && state.browseMode == BrowseMode.DATE && state.statusMeal != null) {
                    item { StatusCard(state.statusMeal, state.secondsRemaining, state.statusIsNextDay) }
                    item {
                        Text(
                            "Today's Menu",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
                itemsIndexed(state.schedule) { _, item ->
                    ScheduleMealCard(item)
                }
            }
        }
    }
}

@Composable
private fun DayHeader(
    state: HomeUiState.Loaded,
    onPrevDay: () -> Unit,
    onNextDay: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onBackToToday: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onPrevDay) {
                Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous day")
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Week ${state.weekNumber}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(
                    dateLabel(state),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                if (state.browseMode == BrowseMode.DATE && !state.isToday) {
                    TextButton(onClick = onBackToToday) { Text("Back to today") }
                }
                if (state.browseMode == BrowseMode.WEEK_PREVIEW) {
                    Text("Previewing menu — not affecting live settings", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row {
                IconButton(onClick = onOpenDatePicker) {
                    Icon(Icons.Filled.CalendarMonth, contentDescription = "Pick a date")
                }
                IconButton(onClick = onNextDay) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "Next day")
                }
            }
        }
    }
}

private fun dateLabel(state: HomeUiState.Loaded): String {
    return if (state.browseMode == BrowseMode.WEEK_PREVIEW) {
        state.dayName
    } else {
        val d = state.selectedDate
        val monthDay = d.format(DateTimeFormatter.ofPattern("MMM d"))
        if (state.isToday) "Today \u2022 ${state.dayName}, $monthDay" else "${state.dayName}, $monthDay"
    }
}

@Composable
private fun WeekPreviewRow(selectedWeek: Int, isPreviewMode: Boolean, onSelectWeek: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        (1..4).forEach { w ->
            FilterChip(
                selected = isPreviewMode && selectedWeek == w,
                onClick = { onSelectWeek(w) },
                label = { Text("Week $w") }
            )
        }
    }
}

@Composable
private fun StatusCard(meal: MealScheduleItem, secondsRemaining: Long, isNextDay: Boolean) {
    val isServing = meal.highlight == MealHighlight.CURRENT
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
            val label = if (isServing) "NOW SERVING" else if (isNextDay) "NEXT MEAL \u2022 TOMORROW" else "NEXT MEAL"
            Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("${mealEmoji(meal.meal)} ${mealName(meal.meal)}", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))

            if (meal.dishes.isEmpty()) {
                Text("No dishes listed for this meal.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                meal.dishes.forEach { dish ->
                    Text("\u2022 $dish", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(vertical = 2.dp))
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(Modifier.height(12.dp))

            val timeLabel = if (isServing) "Serving until" else "Starts at"
            val timeValue = if (isServing) formatTime(meal.timing.endHour, meal.timing.endMinute) else formatTime(meal.timing.startHour, meal.timing.startMinute)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(timeLabel, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    Text(timeValue, style = MaterialTheme.typography.titleLarge)
                }
                if (!isServing) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Time remaining", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        Text(formatCountdown(secondsRemaining), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun ScheduleMealCard(item: MealScheduleItem) {
    val isHighlighted = item.highlight != MealHighlight.NONE
    val containerColor = if (item.highlight == MealHighlight.CURRENT) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (isHighlighted) 6.dp else 1.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = containerColor)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "${mealEmoji(item.meal)} ${mealName(item.meal)}",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (item.highlight == MealHighlight.CURRENT) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    "${formatTime(item.timing.startHour, item.timing.startMinute)} \u2013 ${formatTime(item.timing.endHour, item.timing.endMinute)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (item.highlight == MealHighlight.CURRENT) {
                Spacer(Modifier.height(2.dp))
                Text("Now serving", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            } else if (item.highlight == MealHighlight.NEXT) {
                Spacer(Modifier.height(2.dp))
                Text("Next up", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.height(8.dp))
            if (item.dishes.isEmpty()) {
                Text("No dishes listed.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            } else {
                item.dishes.forEach { dish ->
                    Text("\u2022 $dish", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 1.dp))
                }
            }
        }
    }
}

@Composable
private fun QuickMealsSheetContent(schedule: List<MealScheduleItem>, onMealTapped: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Text(
            "Today's Meals",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        schedule.forEachIndexed { index, item ->
            ListItem(
                headlineContent = { Text("${mealEmoji(item.meal)} ${mealName(item.meal)}") },
                supportingContent = {
                    Text("${formatTime(item.timing.startHour, item.timing.startMinute)} \u2013 ${formatTime(item.timing.endHour, item.timing.endMinute)}")
                },
                modifier = Modifier.clickableListItem { onMealTapped(index) }
            )
        }
    }
}

private fun Modifier.clickableListItem(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

private fun mealName(meal: MealType) = when (meal) {
    MealType.BREAKFAST -> "Breakfast"
    MealType.LUNCH -> "Lunch"
    MealType.SNACKS -> "Snacks"
    MealType.DINNER -> "Dinner"
}

private fun mealEmoji(meal: MealType) = when (meal) {
    MealType.BREAKFAST -> "\uD83C\uDF73"
    MealType.LUNCH -> "\uD83C\uDF5B"
    MealType.SNACKS -> "\u2615"
    MealType.DINNER -> "\uD83C\uDF7D"
}

private fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour < 12) "AM" else "PM"
    val h12 = when {
        hour == 0 -> 12
        hour > 12 -> hour - 12
        else -> hour
    }
    return "%d:%02d %s".format(h12, minute, period)
}

private fun formatCountdown(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}
