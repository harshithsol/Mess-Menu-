package com.messmenu.app.utils

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/**
 * Computes which menu week (1..4) is active for a given date, based on the
 * date Week 1 began. The cycle repeats every 28 days from that anchor date.
 *
 * Each menu week always runs Mon-Sun. Regardless of which weekday the user
 * actually picked as the "week start date" during onboarding, we snap that
 * anchor back to the Monday on/before it before doing any day-count math.
 * This guarantees week-number rollovers always land on a real Monday instead
 * of drifting to whatever weekday the raw anchor happened to be.
 */
object WeekCalculator {

    fun currentWeek(today: LocalDate, week1Start: LocalDate): Int {
        val alignedStart = week1Start.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val daysSinceStart = ChronoUnit.DAYS.between(alignedStart, today)
        val cyclePosition = Math.floorMod(daysSinceStart, 28L) // 0..27
        return (cyclePosition / 7).toInt() + 1 // 1..4
    }
}
