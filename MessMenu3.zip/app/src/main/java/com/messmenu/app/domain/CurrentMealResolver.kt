package com.messmenu.app.domain

import com.messmenu.app.data.model.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Single place that turns "raw cached menu + settings + wall clock time" into
 * a [CurrentMealState]. The home screen and the home-screen widget both call
 * this so their "now serving / next meal" answer can never drift apart.
 */
object CurrentMealResolver {

    fun resolve(now: LocalDateTime, menu: MessMenuData, settings: AppSettings): CurrentMealState {
        val today = now.toLocalDate()
        val week1Start = settings.week1StartDateEpochDay?.let { LocalDate.ofEpochDay(it) } ?: today

        val weekNumber = if (settings.automaticWeekCalculation) {
            com.messmenu.app.utils.WeekCalculator.currentWeek(today, week1Start)
        } else {
            settings.manualWeek
        }

        val todayDow = today.toWeekDay()
        val tomorrow = today.plusDays(1)
        val tomorrowDow = tomorrow.toWeekDay()
        val tomorrowWeek = if (todayDow == WeekDay.SUNDAY) {
            if (weekNumber == 4) 1 else weekNumber + 1
        } else weekNumber

        val todayMenu = menu.weeks[weekNumber].orEmpty().firstOrNull { it.day == todayDow } ?: emptyDay(todayDow)
        val tomorrowMenu = menu.weeks[tomorrowWeek].orEmpty().firstOrNull { it.day == tomorrowDow } ?: emptyDay(tomorrowDow)

        return MealLogic.computeState(now, settings.timings, todayMenu, tomorrowMenu)
    }

    /** Which menu week (1-4) is active right now, honoring the manual override. */
    fun currentWeekNumber(today: LocalDate, settings: AppSettings): Int {
        val week1Start = settings.week1StartDateEpochDay?.let { LocalDate.ofEpochDay(it) } ?: today
        return if (settings.automaticWeekCalculation) {
            com.messmenu.app.utils.WeekCalculator.currentWeek(today, week1Start)
        } else {
            settings.manualWeek
        }
    }

    private fun emptyDay(day: WeekDay) = DayMenu(day, emptyList(), emptyList(), emptyList(), emptyList())

    private fun LocalDate.toWeekDay(): WeekDay = when (this.dayOfWeek) {
        DayOfWeek.MONDAY -> WeekDay.MONDAY
        DayOfWeek.TUESDAY -> WeekDay.TUESDAY
        DayOfWeek.WEDNESDAY -> WeekDay.WEDNESDAY
        DayOfWeek.THURSDAY -> WeekDay.THURSDAY
        DayOfWeek.FRIDAY -> WeekDay.FRIDAY
        DayOfWeek.SATURDAY -> WeekDay.SATURDAY
        DayOfWeek.SUNDAY -> WeekDay.SUNDAY
    }
}
