package com.messmenu.app.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.messmenu.app.data.model.MealType
import com.messmenu.app.data.model.NotificationLeadTime
import com.messmenu.app.data.repository.MenuRepository
import kotlinx.coroutines.flow.firstOrNull
import java.time.LocalDate

class MealNotificationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val repository = MenuRepository(applicationContext)
            val settings = repository.currentSettings()
            val leadTime = settings.notifications.leadTime

            if (leadTime != NotificationLeadTime.NONE) {
                val mealName = tags.firstOrNull { it in setOf("BREAKFAST", "LUNCH", "SNACKS", "DINNER") }
                val meal = mealName?.let { MealType.valueOf(it) }
                if (meal != null) {
                    val menu = repository.menuFlow.firstOrNull()
                    val dishes = resolveDishes(menu, settings, meal)
                    val timing = settings.timings.forMeal(meal)
                    val title = if (leadTime == NotificationLeadTime.AT_START) {
                        "${mealDisplayName(meal)} is being served now"
                    } else {
                        "${mealDisplayName(meal)} starts soon"
                    }
                    val body = if (dishes.isEmpty()) {
                        "Serving window: ${formatTime(timing.startHour, timing.startMinute)} - ${formatTime(timing.endHour, timing.endMinute)}"
                    } else {
                        dishes.take(3).joinToString(", ")
                    }
                    NotificationHelper.postMealNotification(applicationContext, meal, title, body)
                }
            }

            // Always chain the next alert, even if this run had nothing to fire.
            NotificationScheduler.reschedule(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun resolveDishes(
        menu: com.messmenu.app.data.model.MessMenuData?,
        settings: com.messmenu.app.data.model.AppSettings,
        meal: MealType
    ): List<String> {
        if (menu == null) return emptyList()
        val today = LocalDate.now()
        val week1Start = settings.week1StartDateEpochDay?.let { LocalDate.ofEpochDay(it) } ?: today
        val weekNumber = if (settings.automaticWeekCalculation) {
            com.messmenu.app.utils.WeekCalculator.currentWeek(today, week1Start)
        } else {
            settings.manualWeek
        }
        val dow = com.messmenu.app.ui.home.HomeViewModel.toWeekDay(today)
        val dayMenu = menu.weeks[weekNumber].orEmpty().firstOrNull { it.day == dow } ?: return emptyList()
        return dayMenu.forMeal(meal)
    }

    private fun mealDisplayName(meal: MealType) = when (meal) {
        MealType.BREAKFAST -> "Breakfast"
        MealType.LUNCH -> "Lunch"
        MealType.SNACKS -> "Snacks"
        MealType.DINNER -> "Dinner"
    }

    private fun formatTime(hour: Int, minute: Int): String {
        val period = if (hour < 12) "AM" else "PM"
        val h12 = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return "%d:%02d %s".format(h12, minute, period)
    }
}
