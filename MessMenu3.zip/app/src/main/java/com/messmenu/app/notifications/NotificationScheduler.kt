package com.messmenu.app.notifications

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.messmenu.app.data.model.MealTiming
import com.messmenu.app.data.model.MealType
import com.messmenu.app.data.model.NotificationLeadTime
import com.messmenu.app.data.repository.MenuRepository
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/**
 * Meal notifications are implemented as a self-rescheduling chain of
 * WorkManager one-shot jobs (rather than a fixed periodic job), so each
 * alert fires close to its exact minute instead of only within a 15-minute
 * window. [MealNotificationWorker] posts the alert and immediately asks this
 * scheduler to queue the *next* one.
 */
object NotificationScheduler {

    private const val UNIQUE_WORK_NAME = "mess_menu_meal_notification_chain"
    private val ORDER = listOf(MealType.BREAKFAST, MealType.LUNCH, MealType.SNACKS, MealType.DINNER)

    /** Cancels any pending alert and (re)computes + schedules the next one, based on current settings. */
    suspend fun reschedule(context: Context) {
        val repository = MenuRepository(context)
        val settings = repository.currentSettings()

        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)

        if (settings.notifications.leadTime == NotificationLeadTime.NONE) return

        val (meal, triggerAt) = nextTrigger(LocalDateTime.now(), settings.timings, settings.notifications.leadTime)
            ?: return

        val delay = Duration.between(LocalDateTime.now(), triggerAt).toMillis().coerceAtLeast(0)

        val request = OneTimeWorkRequestBuilder<MealNotificationWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag(meal.name)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    /** Finds the soonest (meal, triggerMoment) pair, looking today then rolling into tomorrow. */
    fun nextTrigger(
        now: LocalDateTime,
        timings: com.messmenu.app.data.model.MealTimingsConfig,
        leadTime: NotificationLeadTime
    ): Pair<MealType, LocalDateTime>? {
        if (leadTime == NotificationLeadTime.NONE) return null
        val leadMinutes = when (leadTime) {
            NotificationLeadTime.NONE -> return null
            NotificationLeadTime.AT_START -> 0L
            NotificationLeadTime.MIN_15 -> 15L
            NotificationLeadTime.MIN_30 -> 30L
        }

        val today = now.toLocalDate()
        val candidates = mutableListOf<Pair<MealType, LocalDateTime>>()
        for (dayOffset in 0..1) {
            val date = today.plusDays(dayOffset.toLong())
            for (meal in ORDER) {
                val t: MealTiming = timings.forMeal(meal)
                val startAt = date.atTime(t.startHour, t.startMinute)
                val triggerAt = startAt.minusMinutes(leadMinutes)
                if (triggerAt.isAfter(now) || triggerAt.isEqual(now)) {
                    candidates.add(meal to triggerAt)
                }
            }
        }
        return candidates.minByOrNull { it.second }
    }
}
