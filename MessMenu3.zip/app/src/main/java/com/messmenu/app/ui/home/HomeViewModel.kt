package com.messmenu.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.messmenu.app.data.model.*
import com.messmenu.app.data.repository.MenuRepository
import com.messmenu.app.domain.DayScheduleLogic
import com.messmenu.app.domain.MealHighlight
import com.messmenu.app.domain.MealLogic
import com.messmenu.app.domain.MealScheduleItem
import com.messmenu.app.utils.WeekCalculator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime

/** Whether the home screen is following the calendar (today +/- N days) or previewing a raw week/day of the 4-week cycle. */
enum class BrowseMode { DATE, WEEK_PREVIEW }

sealed interface HomeUiState {
    data object NoMenuImported : HomeUiState

    data class Loaded(
        val browseMode: BrowseMode,
        val selectedDate: LocalDate,
        val isToday: Boolean,
        val weekNumber: Int,
        val dayName: String,
        val schedule: List<MealScheduleItem>,
        // "Now serving / next meal" status card — only populated when isToday && browseMode == DATE
        val statusMeal: MealScheduleItem?,
        val secondsRemaining: Long,
        val statusIsNextDay: Boolean = false
    ) : HomeUiState
}

class HomeViewModel(private val repository: MenuRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.NoMenuImported)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    // Date-mode selection (defaults to today).
    private val _selectedDate = MutableStateFlow(LocalDate.now())

    // Week-preview-mode selection. Stored as a single atomic cursor (0..27 = 4 weeks x 7 days)
    // rather than separate week/day fields, so the two can never momentarily disagree.
    private val _browseMode = MutableStateFlow(BrowseMode.DATE)
    private val _previewCursor = MutableStateFlow(cursorFor(1, toWeekDay(LocalDate.now())))

    private var lastMenu: MessMenuData? = null
    private var lastSettings: AppSettings? = null

    init {
        viewModelScope.launch {
            combine(
                repository.menuFlow,
                repository.settingsFlow,
                _selectedDate,
                _browseMode
            ) { menu, settings, date, mode -> QuadState(menu, settings, date, mode) }
                .collect { s ->
                    lastMenu = s.menu
                    lastSettings = s.settings
                    recompute(s.menu, s.settings, s.date, s.mode)
                }
        }
        // Second-by-second ticker for the live countdown (only matters in DATE mode / today).
        viewModelScope.launch {
            while (true) {
                delay(1000)
                val menu = lastMenu ?: continue
                val settings = lastSettings ?: continue
                if (_browseMode.value == BrowseMode.DATE) {
                    recompute(menu, settings, _selectedDate.value, BrowseMode.DATE)
                }
            }
        }
    }

    private data class QuadState(
        val menu: MessMenuData?,
        val settings: AppSettings,
        val date: LocalDate,
        val mode: BrowseMode
    )

    // ---------- Public actions ----------

    fun goToPreviousDay() {
        _selectedDate.value = _selectedDate.value.minusDays(1)
        _browseMode.value = BrowseMode.DATE
    }

    fun goToNextDay() {
        _selectedDate.value = _selectedDate.value.plusDays(1)
        _browseMode.value = BrowseMode.DATE
    }

    fun goToDate(date: LocalDate) {
        _selectedDate.value = date
        _browseMode.value = BrowseMode.DATE
    }

    fun goToToday() {
        _selectedDate.value = LocalDate.now()
        _browseMode.value = BrowseMode.DATE
    }

    /** Switches to week-preview mode: browse any week/day of the 4-week cycle without touching real settings. */
    fun previewWeekDay(week: Int, day: WeekDay) {
        // Order matters: _browseMode feeds the reactive combine() flow in init{}, which
        // triggers its own recompute() as soon as it changes. Updating the cursor first
        // guarantees that reactive recompute (and our explicit one below) both see the
        // correct week/day — never a stale one from before this call.
        _previewCursor.value = cursorFor(week, day)
        _browseMode.value = BrowseMode.WEEK_PREVIEW
        val menu = lastMenu
        val settings = lastSettings
        if (menu != null && settings != null) recompute(menu, settings, _selectedDate.value, BrowseMode.WEEK_PREVIEW)
    }

    fun previewWeek(week: Int) = previewWeekDay(week, cursorDay(_previewCursor.value))
    fun previewDay(day: WeekDay) = previewWeekDay(cursorWeek(_previewCursor.value), day)

    /** Moves one day forward within the previewed week, rolling into the next week (wrapping 4 -> 1) on Sunday -> Monday. */
    fun previewNextDay() {
        val nextCursor = Math.floorMod(_previewCursor.value + 1, 28)
        previewWeekDay(cursorWeek(nextCursor), cursorDay(nextCursor))
    }

    /** Moves one day backward within the previewed week, rolling into the previous week (wrapping 1 -> 4) on Monday -> Sunday. */
    fun previewPreviousDay() {
        val prevCursor = Math.floorMod(_previewCursor.value - 1, 28)
        previewWeekDay(cursorWeek(prevCursor), cursorDay(prevCursor))
    }

    // ---------- Core computation ----------

    private fun recompute(menu: MessMenuData?, settings: AppSettings, selectedDate: LocalDate, mode: BrowseMode) {
        if (menu == null) {
            _uiState.value = HomeUiState.NoMenuImported
            return
        }

        val now = LocalDateTime.now()
        val realToday = now.toLocalDate()

        if (mode == BrowseMode.WEEK_PREVIEW) {
            val week = cursorWeek(_previewCursor.value)
            val day = cursorDay(_previewCursor.value)
            val dayMenu = menu.weeks[week].orEmpty().firstOrNull { it.day == day } ?: emptyDay(day)
            val schedule = DayScheduleLogic.buildSchedule(now, settings.timings, dayMenu, isToday = false)
            _uiState.value = HomeUiState.Loaded(
                browseMode = BrowseMode.WEEK_PREVIEW,
                selectedDate = selectedDate,
                isToday = false,
                weekNumber = week,
                dayName = day.name.lowercase().replaceFirstChar { it.uppercase() },
                schedule = schedule,
                statusMeal = null,
                secondsRemaining = 0
            )
            return
        }

        // DATE mode
        val isToday = selectedDate == realToday
        val week1Start = settings.week1StartDateEpochDay?.let { LocalDate.ofEpochDay(it) } ?: realToday

        // Manual override only makes sense for "right now" (the mess's actual current week);
        // any other browsed date always uses the automatic 4-week cycle math.
        val weekNumber = if (isToday && !settings.automaticWeekCalculation) {
            settings.manualWeek
        } else {
            WeekCalculator.currentWeek(selectedDate, week1Start)
        }

        val dow = toWeekDay(selectedDate)
        val dayMenu = menu.weeks[weekNumber].orEmpty().firstOrNull { it.day == dow } ?: emptyDay(dow)
        val schedule = DayScheduleLogic.buildSchedule(now, settings.timings, dayMenu, isToday = isToday)

        var statusMeal: MealScheduleItem? = null
        var secondsRemaining = 0L
        var statusIsNextDay = false

        if (isToday) {
            val tomorrow = selectedDate.plusDays(1)
            val tomorrowDow = toWeekDay(tomorrow)
            val tomorrowWeek = if (dow == WeekDay.SUNDAY) {
                if (weekNumber == 4) 1 else weekNumber + 1
            } else weekNumber
            val tomorrowMenu = menu.weeks[tomorrowWeek].orEmpty().firstOrNull { it.day == tomorrowDow } ?: emptyDay(tomorrowDow)

            val mealState = MealLogic.computeState(now, settings.timings, dayMenu, tomorrowMenu)
            secondsRemaining = MealLogic.secondsUntil(now, mealState)
            statusIsNextDay = mealState.isNextDay
            statusMeal = MealScheduleItem(
                meal = mealState.meal,
                dishes = mealState.dishes,
                timing = mealState.timing,
                highlight = if (mealState.status == MealStatus.NOW_SERVING) MealHighlight.CURRENT else MealHighlight.NEXT
            )
        }

        _uiState.value = HomeUiState.Loaded(
            browseMode = BrowseMode.DATE,
            selectedDate = selectedDate,
            isToday = isToday,
            weekNumber = weekNumber,
            dayName = dow.name.lowercase().replaceFirstChar { it.uppercase() },
            schedule = schedule,
            statusMeal = statusMeal,
            secondsRemaining = secondsRemaining,
            statusIsNextDay = statusIsNextDay
        )
    }

    private fun emptyDay(day: WeekDay) = DayMenu(day, emptyList(), emptyList(), emptyList(), emptyList())

    companion object {
        fun toWeekDay(date: LocalDate): WeekDay = when (date.dayOfWeek) {
            DayOfWeek.MONDAY -> WeekDay.MONDAY
            DayOfWeek.TUESDAY -> WeekDay.TUESDAY
            DayOfWeek.WEDNESDAY -> WeekDay.WEDNESDAY
            DayOfWeek.THURSDAY -> WeekDay.THURSDAY
            DayOfWeek.FRIDAY -> WeekDay.FRIDAY
            DayOfWeek.SATURDAY -> WeekDay.SATURDAY
            DayOfWeek.SUNDAY -> WeekDay.SUNDAY
        }

        /** Encodes (week 1..4, day) as a single 0..27 cursor: week and day always move together, atomically. */
        fun cursorFor(week: Int, day: WeekDay): Int = (week - 1) * 7 + day.ordinal
        fun cursorWeek(cursor: Int): Int = (cursor / 7) + 1
        fun cursorDay(cursor: Int): WeekDay = WeekDay.entries[cursor % 7]
    }
}
