package com.messmenu.app.widget

import android.content.Context
import android.content.Intent
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalContext
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.unit.dp
import com.messmenu.app.MainActivity
import com.messmenu.app.data.model.CurrentMealState
import com.messmenu.app.data.model.MealStatus
import com.messmenu.app.data.model.MealType
import com.messmenu.app.data.repository.MenuRepository
import com.messmenu.app.domain.CurrentMealResolver
import kotlinx.coroutines.flow.first
import java.time.LocalDateTime
import androidx.compose.ui.graphics.Color as ComposeColor

/**
 * Home screen widget: shows what's serving now (or next) and refreshes on a
 * schedule via [WidgetScheduler]. Reuses [CurrentMealResolver] so the widget
 * can never disagree with the in-app "now serving" answer.
 */
class MessMenuWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = MenuRepository(context)
        val menu = repository.menuFlow.first()
        val settings = repository.settingsFlow.first()

        val content: CurrentMealState? = menu?.let {
            CurrentMealResolver.resolve(LocalDateTime.now(), it, settings)
        }
        val weekNumber = menu?.let {
            CurrentMealResolver.currentWeekNumber(LocalDateTime.now().toLocalDate(), settings)
        }
        val dayName = LocalDateTime.now().dayOfWeek.name.lowercase()
            .replaceFirstChar { it.uppercase() }

        provideContent {
            WidgetContent(weekNumber = weekNumber, dayName = dayName, meal = content)
        }
    }
}

private val AccentOrange = ComposeColor(0xFFFF7A1A)
private val TextWhite = ComposeColor(0xFFF5F5F5)
private val TextDim = ComposeColor(0xFFA0A0A3)

@androidx.compose.runtime.Composable
private fun WidgetContent(weekNumber: Int?, dayName: String, meal: CurrentMealState?) {
    val context = LocalContext.current
    val openAppIntent = Intent(context, MainActivity::class.java)

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .padding(16.dp)
            .clickable(actionStartActivity(openAppIntent)),
    ) {
        if (weekNumber == null || meal == null) {
            Text(
                "No menu imported.",
                style = TextStyle(color = ColorProvider(TextWhite), fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = GlanceModifier.height(4.dp))
            Text("Open Mess Menu to import one.", style = TextStyle(color = ColorProvider(TextDim)))
            return@Column
        }

        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                "Week $weekNumber \u2022 $dayName",
                style = TextStyle(color = ColorProvider(TextDim), fontWeight = FontWeight.Medium)
            )
        }
        Spacer(modifier = GlanceModifier.height(6.dp))

        val statusLabel = if (meal.status == MealStatus.NOW_SERVING) "NOW SERVING" else "NEXT MEAL"
        Text(
            statusLabel,
            style = TextStyle(color = ColorProvider(AccentOrange), fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = GlanceModifier.height(2.dp))
        Text(
            "${mealEmoji(meal.meal)} ${mealName(meal.meal)}",
            style = TextStyle(color = ColorProvider(TextWhite), fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = GlanceModifier.height(4.dp))

        if (meal.dishes.isNotEmpty()) {
            val maxDishesShown = 3
            val shown = meal.dishes.take(maxDishesShown)
            val extraCount = meal.dishes.size - shown.size
            val dishesText = if (extraCount > 0) {
                shown.joinToString(", ") + " +$extraCount more"
            } else {
                shown.joinToString(", ")
            }
            Text(
                dishesText,
                style = TextStyle(color = ColorProvider(TextWhite)),
                maxLines = 2
            )
            Spacer(modifier = GlanceModifier.height(4.dp))
        }

        val timeLabel = if (meal.status == MealStatus.NOW_SERVING) {
            "Until ${formatTime(meal.timing.endHour, meal.timing.endMinute)}"
        } else {
            "Starts at ${formatTime(meal.timing.startHour, meal.timing.startMinute)}"
        }
        Text(timeLabel, style = TextStyle(color = ColorProvider(TextDim)))
    }
}

private fun mealName(meal: MealType) = when (meal) {
    MealType.BREAKFAST -> "Breakfast"
    MealType.LUNCH -> "Lunch"
    MealType.SNACKS -> "Snacks"
    MealType.DINNER -> "Dinner"
}

private fun mealEmoji(meal: MealType) = when (meal) {
    MealType.BREAKFAST -> "\uD83C\uDF73"
    MealType.LUNCH -> "\uD83C\uDF5B"
    MealType.SNACKS -> "\u2615"
    MealType.DINNER -> "\uD83C\uDF7D"
}

private fun formatTime(hour: Int, minute: Int): String {
    val period = if (hour < 12) "AM" else "PM"
    val h12 = when {
        hour == 0 -> 12
        hour > 12 -> hour - 12
        else -> hour
    }
    return "%d:%02d %s".format(h12, minute, period)
}
