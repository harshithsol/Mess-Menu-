package com.messmenu.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.messmenu.app.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "mess_menu_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val WEEK1_START = longPreferencesKey("week1_start_epoch_day")
        val AUTO_WEEK = booleanPreferencesKey("automatic_week_calculation")
        val MANUAL_WEEK = intPreferencesKey("manual_week")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_complete")
        val TIMINGS_JSON = stringPreferencesKey("timings_json")
        val NOTIF_JSON = stringPreferencesKey("notifications_json")
        val CACHED_MENU_JSON = stringPreferencesKey("cached_menu_json")
    }

    private val json = Json { ignoreUnknownKeys = true }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            week1StartDateEpochDay = prefs[Keys.WEEK1_START],
            automaticWeekCalculation = prefs[Keys.AUTO_WEEK] ?: true,
            manualWeek = prefs[Keys.MANUAL_WEEK] ?: 1,
            onboardingComplete = prefs[Keys.ONBOARDING_DONE] ?: false,
            timings = prefs[Keys.TIMINGS_JSON]?.let {
                runCatching { json.decodeFromString<MealTimingsConfig>(it) }.getOrNull()
            } ?: MealTimingsConfig.default(),
            notifications = prefs[Keys.NOTIF_JSON]?.let {
                runCatching { json.decodeFromString<NotificationSettings>(it) }.getOrNull()
            } ?: NotificationSettings()
        )
    }

    suspend fun currentSettings(): AppSettings = settingsFlow.first()

    suspend fun setWeek1Start(epochDay: Long) {
        context.dataStore.edit { it[Keys.WEEK1_START] = epochDay }
    }

    suspend fun setAutomaticWeekCalculation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_WEEK] = enabled }
    }

    suspend fun setManualWeek(week: Int) {
        context.dataStore.edit { it[Keys.MANUAL_WEEK] = week }
    }

    suspend fun setOnboardingComplete(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setTimings(timings: MealTimingsConfig) {
        context.dataStore.edit { it[Keys.TIMINGS_JSON] = json.encodeToString(timings) }
    }

    suspend fun setNotificationSettings(settings: NotificationSettings) {
        context.dataStore.edit { it[Keys.NOTIF_JSON] = json.encodeToString(settings) }
    }

    // --- Cached parsed menu (survives deletion of the original Excel file) ---

    val cachedMenuFlow: Flow<MessMenuData?> = context.dataStore.data.map { prefs ->
        prefs[Keys.CACHED_MENU_JSON]?.let {
            runCatching { json.decodeFromString<MessMenuData>(it) }.getOrNull()
        }
    }

    suspend fun saveMenu(menu: MessMenuData) {
        context.dataStore.edit { it[Keys.CACHED_MENU_JSON] = json.encodeToString(menu) }
    }

    suspend fun deleteMenu() {
        context.dataStore.edit { it.remove(Keys.CACHED_MENU_JSON) }
    }
}
