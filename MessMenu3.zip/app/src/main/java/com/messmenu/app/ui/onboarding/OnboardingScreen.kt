@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.messmenu.app.ui.onboarding

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.messmenu.app.data.repository.MenuRepository
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneOffset

private enum class Step { WELCOME, IMPORT, WEEK_START, TIMINGS, FINISH }

@Composable
fun OnboardingScreen(repository: MenuRepository, onFinished: () -> Unit) {
    var step by remember { mutableStateOf(Step.WELCOME) }
    var importedOk by remember { mutableStateOf(false) }
    var importError by remember { mutableStateOf<String?>(null) }
    var week1Start by remember { mutableStateOf(LocalDate.now()) }
    val scope = rememberCoroutineScope()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val result = repository.importMenu(uri)
            result.onSuccess {
                importedOk = true
                importError = null
            }.onFailure {
                importError = it.message ?: "Could not read the file."
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        when (step) {
            Step.WELCOME -> {
                Text("Welcome to Mess Menu", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Know what's being served right now, without asking around.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(32.dp))
                Button(onClick = { step = Step.IMPORT }, modifier = Modifier.fillMaxWidth()) { Text("Get started") }
            }

            Step.IMPORT -> {
                Text("Import your mess menu", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pick a .txt file with one line per day: " +
                        "Week|Day|Breakfast|Lunch|Snacks|Dinner (dishes separated by commas).",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { filePicker.launch(arrayOf("text/plain")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (importedOk) "Re-select file" else "Choose Text File") }

                importError?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                if (importedOk) {
                    Spacer(Modifier.height(12.dp))
                    Text("Menu imported successfully.", color = MaterialTheme.colorScheme.primary)
                }

                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { step = Step.WELCOME }, modifier = Modifier.weight(1f)) { Text("Back") }
                    Button(
                        onClick = { step = Step.WEEK_START },
                        enabled = importedOk,
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                }
            }

            Step.WEEK_START -> {
                Text("When does Week 1 begin?", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pick the date your mess starts Week 1 of its 4-week cycle. " +
                        "For a clean weekly rotation, choose a Monday.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(20.dp))
                DatePickerField(date = week1Start, onDateChange = { week1Start = it })
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { step = Step.IMPORT }, modifier = Modifier.weight(1f)) { Text("Back") }
                    Button(
                        onClick = {
                            scope.launch {
                                repository.setWeek1Start(week1Start.toEpochDay())
                                step = Step.TIMINGS
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Next") }
                }
            }

            Step.TIMINGS -> {
                Text("Meal timings", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Default timings are Breakfast 7-8 AM, Lunch 1-2 PM, Snacks 5:30-6:30 PM, " +
                        "Dinner 8-9 PM. You can change these later in Settings.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
                Button(onClick = { step = Step.FINISH }, modifier = Modifier.fillMaxWidth()) { Text("Next") }
            }

            Step.FINISH -> {
                Text("All set!", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "You're ready to go. You can revisit any of this later from Settings.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(32.dp))
                Button(
                    onClick = {
                        scope.launch {
                            repository.setOnboardingComplete(true)
                            onFinished()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Go to Home") }
            }
        }
    }
}

@Composable
private fun DatePickerField(date: LocalDate, onDateChange: (LocalDate) -> Unit) {
    val state = rememberDatePickerState(
        initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    )
    LaunchedEffect(state.selectedDateMillis) {
        state.selectedDateMillis?.let {
            onDateChange(java.time.Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
        }
    }
    Card {
        DatePicker(state = state, showModeToggle = false)
    }
}
