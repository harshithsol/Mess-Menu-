package com.messmenu.app.data.repository

import android.content.Context
import android.net.Uri
import com.messmenu.app.data.datastore.PreferencesManager
import com.messmenu.app.data.textparse.TextMenuParser
import com.messmenu.app.data.model.*
import com.messmenu.app.widget.WidgetScheduler
import com.messmenu.app.notifications.NotificationScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Single source of truth for menu + settings. UI talks only to this class.
 */
class MenuRepository(
    private val context: Context,
    private val prefs: PreferencesManager = PreferencesManager(context)
) {
    val settingsFlow: Flow<AppSettings> = prefs.settingsFlow
    val menuFlow: Flow<MessMenuData?> = prefs.cachedMenuFlow

    suspend fun currentSettings() = prefs.currentSettings()

    /** Reads and parses the text file the user picked via SAF, then caches it. */
    suspend fun importMenu(uri: Uri): Result<MessMenuData> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Could not open the selected file.")
            val parsed = stream.use { TextMenuParser.parse(it) }
            prefs.saveMenu(parsed)
            parsed
        }.also { if (it.isSuccess) WidgetScheduler.refreshNow(context) }
    }

    suspend fun deleteMenu() {
        prefs.deleteMenu()
        WidgetScheduler.refreshNow(context)
    }

    suspend fun setWeek1Start(epochDay: Long) {
        prefs.setWeek1Start(epochDay)
        WidgetScheduler.refreshNow(context)
    }

    suspend fun setAutomaticWeekCalculation(enabled: Boolean) {
        prefs.setAutomaticWeekCalculation(enabled)
        WidgetScheduler.refreshNow(context)
    }

    suspend fun setManualWeek(week: Int) {
        prefs.setManualWeek(week)
        WidgetScheduler.refreshNow(context)
    }

    suspend fun setOnboardingComplete(done: Boolean) = prefs.setOnboardingComplete(done)

    suspend fun setTimings(timings: MealTimingsConfig) {
        prefs.setTimings(timings)
        WidgetScheduler.refreshNow(context)
        NotificationScheduler.reschedule(context)
    }

    suspend fun setNotificationSettings(settings: NotificationSettings) {
        prefs.setNotificationSettings(settings)
        NotificationScheduler.reschedule(context)
    }
}
