package com.messmenu.app.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Thin CoroutineWorker wrapper so [BootReceiver] (which can't safely do
 * suspend work in onReceive) can trigger [NotificationScheduler.reschedule].
 */
class RescheduleWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            NotificationScheduler.reschedule(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
