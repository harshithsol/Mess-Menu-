package com.messmenu.app.data.model

import kotlinx.serialization.Serializable

enum class MealType { BREAKFAST, LUNCH, SNACKS, DINNER }

enum class WeekDay { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY }

/** One day's dishes for all four meals. */
@Serializable
data class DayMenu(
    val day: WeekDay,
    val breakfast: List<String>,
    val lunch: List<String>,
    val snacks: List<String>,
    val dinner: List<String>
) {
    fun forMeal(meal: MealType): List<String> = when (meal) {
        MealType.BREAKFAST -> breakfast
        MealType.LUNCH -> lunch
        MealType.SNACKS -> snacks
        MealType.DINNER -> dinner
    }
}

/** week (1..4) -> day -> DayMenu */
@Serializable
data class MessMenuData(
    val weeks: Map<Int, List<DayMenu>>
)

@Serializable
data class MealTiming(
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int
) {
    fun startTotalMinutes() = startHour * 60 + startMinute
    fun endTotalMinutes() = endHour * 60 + endMinute
}

@Serializable
data class MealTimingsConfig(
    val breakfast: MealTiming = MealTiming(7, 0, 8, 0),
    val lunch: MealTiming = MealTiming(13, 0, 14, 0),
    val snacks: MealTiming = MealTiming(17, 30, 18, 30),
    val dinner: MealTiming = MealTiming(20, 0, 21, 0)
) {
    fun forMeal(meal: MealType): MealTiming = when (meal) {
        MealType.BREAKFAST -> breakfast
        MealType.LUNCH -> lunch
        MealType.SNACKS -> snacks
        MealType.DINNER -> dinner
    }

    companion object {
        fun default() = MealTimingsConfig()
    }
}

enum class MealStatus { NOW_SERVING, UPCOMING }

data class CurrentMealState(
    val status: MealStatus,
    val meal: MealType,
    val dishes: List<String>,
    val timing: MealTiming,
    val isNextDay: Boolean = false
)

/** One row in a full day's meal schedule (used by the redesigned Home screen and the widget). */
data class MealScheduleEntry(
    val meal: MealType,
    val timing: MealTiming,
    val dishes: List<String>,
    val isCurrent: Boolean,
    val isNext: Boolean,
    val isPast: Boolean
)

enum class NotificationLeadTime { NONE, AT_START, MIN_15, MIN_30 }

@Serializable
data class NotificationSettings(
    val leadTime: NotificationLeadTime = NotificationLeadTime.NONE
)

@Serializable
data class AppSettings(
    val week1StartDateEpochDay: Long? = null,
    val automaticWeekCalculation: Boolean = true,
    val manualWeek: Int = 1,
    val onboardingComplete: Boolean = false,
    val timings: MealTimingsConfig = MealTimingsConfig.default(),
    val notifications: NotificationSettings = NotificationSettings()
)
