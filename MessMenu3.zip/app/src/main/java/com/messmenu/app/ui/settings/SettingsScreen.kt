package com.messmenu.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.messmenu.app.data.model.MealTiming
import com.messmenu.app.data.model.MealTimingsConfig
import com.messmenu.app.data.model.NotificationLeadTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    var snackbarMessage by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            snackbarMessage = null
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        viewModel.importMenu(uri) { success, message ->
            snackbarMessage = message
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            SectionTitle("Menu")
            Button(
                onClick = { filePicker.launch(arrayOf("text/plain")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (state.menu == null) "Import Text Menu" else "Replace Menu") }

            if (state.menu != null) {
                OutlinedButton(onClick = { viewModel.deleteMenu() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Delete Menu")
                }
                PreviewMenuCard(state.menu)
            }

            SectionTitle("Week Cycle")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Automatic week calculation")
                Switch(
                    checked = state.settings.automaticWeekCalculation,
                    onCheckedChange = { viewModel.setAutomaticWeekCalculation(it) }
                )
            }
            if (!state.settings.automaticWeekCalculation) {
                Text("Manual week: ${state.settings.manualWeek}", modifier = Modifier.padding(top = 4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..4).forEach { w ->
                        FilterChip(
                            selected = state.settings.manualWeek == w,
                            onClick = { viewModel.setManualWeek(w) },
                            label = { Text("Week $w") }
                        )
                    }
                }
            }

            SectionTitle("Meal Timings")
            TimingsEditor(
                timings = state.settings.timings,
                onChange = { viewModel.setTimings(it) },
                onRestoreDefaults = { viewModel.restoreDefaultTimings() }
            )

            SectionTitle("Notifications")
            NotificationLeadTime.entries.forEach { lead ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = state.settings.notifications.leadTime == lead,
                        onClick = { viewModel.setNotificationLeadTime(lead) }
                    )
                    Text(leadTimeLabel(lead))
                }
            }

            SectionTitle("About")
            Text("Mess Menu v1.0.0 — works fully offline once a menu is imported.")
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun PreviewMenuCard(menu: com.messmenu.app.data.model.MessMenuData?) {
    if (menu == null) return
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Imported: ${menu.weeks.size} week(s), ${menu.weeks.values.sumOf { it.size }} day rows.")
        }
    }
}

@Composable
private fun TimingsEditor(
    timings: MealTimingsConfig,
    onChange: (MealTimingsConfig) -> Unit,
    onRestoreDefaults: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TimingRow("Breakfast", timings.breakfast) { onChange(timings.copy(breakfast = it)) }
        TimingRow("Lunch", timings.lunch) { onChange(timings.copy(lunch = it)) }
        TimingRow("Snacks", timings.snacks) { onChange(timings.copy(snacks = it)) }
        TimingRow("Dinner", timings.dinner) { onChange(timings.copy(dinner = it)) }
        OutlinedButton(onClick = onRestoreDefaults, modifier = Modifier.fillMaxWidth()) {
            Text("Restore Default Timings")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimingRow(label: String, timing: MealTiming, onChange: (MealTiming) -> Unit) {
    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AssistChip(onClick = { showStartPicker = true }, label = { Text("Start ${fmt(timing.startHour, timing.startMinute)}") })
                AssistChip(onClick = { showEndPicker = true }, label = { Text("End ${fmt(timing.endHour, timing.endMinute)}") })
            }
        }
    }

    if (showStartPicker) {
        val tps = rememberTimePickerState(initialHour = timing.startHour, initialMinute = timing.startMinute, is24Hour = false)
        TimePickerDialog(
            onDismiss = { showStartPicker = false },
            onConfirm = {
                onChange(timing.copy(startHour = tps.hour, startMinute = tps.minute))
                showStartPicker = false
            }
        ) { TimePicker(state = tps) }
    }
    if (showEndPicker) {
        val tps = rememberTimePickerState(initialHour = timing.endHour, initialMinute = timing.endMinute, is24Hour = false)
        TimePickerDialog(
            onDismiss = { showEndPicker = false },
            onConfirm = {
                onChange(timing.copy(endHour = tps.hour, endMinute = tps.minute))
                showEndPicker = false
            }
        ) { TimePicker(state = tps) }
    }
}

@Composable
private fun TimePickerDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    content: @Composable () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onConfirm) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        text = { content() }
    )
}

private fun fmt(hour: Int, minute: Int): String {
    val period = if (hour < 12) "AM" else "PM"
    val h12 = when {
        hour == 0 -> 12
        hour > 12 -> hour - 12
        else -> hour
    }
    return "%d:%02d %s".format(h12, minute, period)
}

private fun leadTimeLabel(l: NotificationLeadTime) = when (l) {
    NotificationLeadTime.NONE -> "Off"
    NotificationLeadTime.MIN_30 -> "Notify 30 minutes before meals"
    NotificationLeadTime.MIN_15 -> "Notify 15 minutes before meals"
    NotificationLeadTime.AT_START -> "Notify when meal starts"
}
