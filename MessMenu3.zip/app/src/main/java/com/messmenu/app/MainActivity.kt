package com.messmenu.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.messmenu.app.data.repository.MenuRepository
import com.messmenu.app.navigation.MessMenuNavGraph
import com.messmenu.app.notifications.NotificationHelper
import com.messmenu.app.notifications.NotificationScheduler
import com.messmenu.app.ui.theme.MessMenuTheme
import com.messmenu.app.widget.WidgetScheduler
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var repository: MenuRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repository = MenuRepository(applicationContext)
        NotificationHelper.ensureChannel(applicationContext)
        WidgetScheduler.schedulePeriodicRefresh(applicationContext)

        val requestNotificationPermission = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) {
            // Whether granted or denied, (re)schedule — reschedule() itself checks
            // the current preference; a denial just means posts get silently skipped.
            lifecycleScope.launch { NotificationScheduler.reschedule(applicationContext) }
        }

        setContent {
            MessMenuTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    MessMenuNavGraph(repository = repository)
                }
            }
        }

        // Android 13+ requires this runtime permission before any notification can post.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            lifecycleScope.launch { NotificationScheduler.reschedule(applicationContext) }
        }
    }
}
